GameLocale.start();
